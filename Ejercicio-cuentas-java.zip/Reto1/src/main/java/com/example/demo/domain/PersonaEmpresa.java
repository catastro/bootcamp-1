package com.example.demo.domain;

public class PersonaEmpresa extends Persona{
    private String ruc;


    public PersonaEmpresa(int id, int edad, String nombre, String ruc) {
        super(id, edad, nombre);
        this.ruc = ruc;
    }


    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    @Override
    public String toString() {
        return "PersonaEmpresa{" +
                "ruc='" + ruc + '\'' +
                '}';
    }


}
