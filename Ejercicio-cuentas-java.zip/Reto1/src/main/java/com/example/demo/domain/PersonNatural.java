package com.example.demo.domain;

public class PersonNatural extends Persona{
    private String dni;
    public PersonNatural(int id, int edad, String nombre, String dni) {
        super(id, edad, nombre);
        this.dni = dni;
    }




    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Persona{" +
                "id=" + this.getId() +
                ", edad=" + this.getEdad() +
                ", nombre='" + this.getNombre() + '\'' +
                "dni='" + dni + '\'' +
                '}';
    }


}
