package com.example.demo.domain;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class Cuenta {
    private String numero;
    private Persona persona;
    private String moneda;
    private BigDecimal saldo;
    private List<Movimiento> movimiento;


    public boolean depositar(BigDecimal monto) {
        Movimiento movimiento = new Movimiento();
        movimiento.setId(this.movimiento.size()+1);
        movimiento.setMonto(monto);
        movimiento.setTipo("deposito");

        this.movimiento.add(movimiento);
        this.saldo = this.saldo.add(monto);
        return true;
    }

    public boolean retirar(BigDecimal monto) {
        Movimiento movimiento = new Movimiento();
        movimiento.setId(this.movimiento.size()+1);
        movimiento.setMonto(monto);
        movimiento.setTipo("retiro");

        this.movimiento.add(movimiento);
        this.saldo = this.saldo.subtract(monto);
        return true;
    }


    public List<Movimiento> getMovimiento() {
        return movimiento;
    }

    public void setMovimiento(List<Movimiento> movimiento) {
        this.movimiento = movimiento;
    }


    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Cuenta{" +
                "numero='" + numero + '\'' +
                ", persona=" + persona +
                ", moneda='" + moneda + '\'' +
                ", saldo=" + saldo +
                ", movimiento=" + movimiento +
                '}';
    }



}
