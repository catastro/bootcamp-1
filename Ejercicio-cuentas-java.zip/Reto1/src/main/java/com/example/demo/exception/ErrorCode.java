package com.example.demo.exception;

public enum ErrorCode {
    ENTITY_NOT_FOUND,
    LAZY_INITIALIZATION,
    NO_SUCH_ELEMENT
}
