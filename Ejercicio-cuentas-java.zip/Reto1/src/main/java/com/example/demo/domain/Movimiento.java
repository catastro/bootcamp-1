package com.example.demo.domain;

import java.math.BigDecimal;

public class Movimiento{

    private int id;
    private BigDecimal monto;
    private String tipo;

    public Movimiento(int id, BigDecimal monto, String tipo) {
        this.id = id;
        this.monto = monto;
        this.tipo = tipo;
    }

    public Movimiento() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BigDecimal getMonto() {
        return monto;
    }

    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Movimiento{" +
                "id=" + id +
                ", monto=" + monto +
                ", tipo='" + tipo + '\'' +
                '}';
    }



}
