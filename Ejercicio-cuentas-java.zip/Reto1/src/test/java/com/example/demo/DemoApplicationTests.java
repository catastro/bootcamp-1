package com.example.demo;

import com.example.demo.domain.Cuenta;
import com.example.demo.domain.Movimiento;
import com.example.demo.domain.PersonNatural;
import com.example.demo.domain.Persona;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

//@SpringBootTest
@Slf4j
class DemoApplicationTests {

	@Test
	void digitoVerificador() {
		String documentNumber = "43012421";
		int[] multiplicador = {3,2,7,6,5,4,3,2};
		int[] serieNumerica = {6,7,8,9,0,1,1,2,3,4,5};
		int suma = 0;

		char[] array = documentNumber.toCharArray();

		log.info("arrat", array);

		for(int i = 0; i< documentNumber.length(); i++) {
			suma = suma + (multiplicador[i] * Integer.parseInt(String.valueOf(array[i])));

		}

		log.info("suma {}", suma);

		int residuo = suma%11;
		int resta = 11 - residuo;
		if (11 == resta ) {
			resta = 0;
		}
		int adicion = resta +1;
		log.info("digito verificador {}", serieNumerica[adicion-1]);
	}


	@Test
	void main() {
		var persona = new PersonNatural(1,25,"Pepito", "75545588");
		log.info("Persona {}", persona.toString());

		List<Movimiento> movimientos = new ArrayList<>();

		var cuenta = new Cuenta();
		cuenta.setMoneda("SOLES");
		cuenta.setPersona(persona);
		cuenta.setNumero("45547-5455145");
		cuenta.setSaldo(BigDecimal.valueOf(1000));
		cuenta.setMovimiento(movimientos);

		cuenta.depositar(BigDecimal.valueOf(50));
		cuenta.retirar(BigDecimal.valueOf(100));

		log.info("Datos de cuenta {}", cuenta.toString());

	}



}
